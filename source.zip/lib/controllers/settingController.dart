import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingController extends GetxController {
  @override
  Future<void> onInit() async {
    super.onInit();
  }
}
