import 'package:flutter/material.dart';

class TakreeGadwel extends StatelessWidget {
  const TakreeGadwel({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Row(
            children: [
              Image.asset(
                "assets/logo1.png",
                height: 100,
              ),
              Image.asset(
                "assets/logo1.png",
                height: 100,
              ),
              Image.asset(
                "assets/logo1.png",
                height: 100,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
